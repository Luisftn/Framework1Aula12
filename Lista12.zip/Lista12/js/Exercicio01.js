$(function() {
    setInterval(function() {
        $('h1').fadeOut('slow');
        $('h1').fadeIn('slow');
    }, 1000);

    $('#ItensSeco').focus(function() {
        $('#ItensSeco').css("background-color", "black");
        $('#ItensSeco').css("color", "white");
    });
    $('#ItensSeco').blur(function() {
        $('#ItensSeco').css("background-color", "white");
        $('#ItensSeco').css("color", "black");
    });


    $('#TotalSeco').focus(function() {
        $('#TotalSeco').css("background-color", "black");
        $('#TotalSeco').css("color", "white");
    });
    $('#TotalSeco').blur(function() {
        $('#TotalSeco').css("background-color", "white");
        $('#TotalSeco').css("color", "black");
    });


    $('#TotalMolhado').blur(function() {
        $('#TotalMolhado').css("background-color", "white");
        $('#TotalMolhado').css("color", "black");
    });
    $('#TotalMolhado').focus(function() {
        $('#TotalMolhado').css("background-color", "black");
        $('#TotalMolhado').css("color", "white");
    });


    $('#ItensMolhado').blur(function() {
        $('#ItensMolhado').css("background-color", "white");
        $('#ItensMolhado').css("color", "black");
    });
    $('#ItensMolhado').focus(function() {
        $('#ItensMolhado').css("background-color", "black");
        $('#ItensMolhado').css("color", "white");
    });


    $('#TotalFragil').blur(function() {
        $('#TotalFragil').css("background-color", "white");
        $('#TotalFragil').css("color", "black");
    });
    $('#TotalFragil').focus(function() {
        $('#TotalFragil').css("background-color", "black");
        $('#TotalFragil').css("color", "white");
    });


    $('#ItensFragil').blur(function() {
        $('#ItensFragil').css("background-color", "white");
        $('#ItensFragil').css("color", "black");
    });
    $('#ItensFragil').focus(function() {
        $('#ItensFragil').css("background-color", "black");
        $('#ItensFragil').css("color", "white");
    });

    $('#BotaoCalcular').click(function() {
        var ItensSeco = document.getElementById('ItensSeco');
        var ItensMolhado = document.getElementById('ItensMolhado');
        var ItensFragil = document.getElementById('ItensFragil');
        var ITotaSeco = document.getElementById('TotalSeco');
        var ITotaMolhado = document.getElementById('TotalMolhado');
        var ITotaFragil = document.getElementById('TotalFragil');

        var SacolaItensSeco = 0;
        var SacolaItensMolhado = 0;
        var SacolaItensFragil = 0;

        $('#LabelItensSecos').css("color", "black");
        $('#LabelItensSecos').css("background-color", "");
        $('#LabelItensMolhados').css("color", "black");
        $('#LabelItensMolhados').css("background-color", "");
        $('#LabelItensFrageis').css("color", "black");
        $('#LabelItensFrageis').css("background-color", "");

        if (ItensSeco.value == "") {
            alert("Quantidade de itens seco não informada.");
            $('#LabelItensSecos').css("color", "white");
            $('#LabelItensSecos').css("background-color", "red");
        } else if (ItensMolhado.value == "") {
            alert("Quantidade de itens molhado não informada.");
            $('#LabelItensMolhados').css("color", "white");
            $('#LabelItensMolhados').css("background-color", "red");
        } else if (ItensFragil.value == "") {
            alert("Quantidade de itens frageis não informada.");
            $('#LabelItensFrageis').css("color", "white");
            $('#LabelItensFrageis').css("background-color", "red");
        } else {
            SacolaItensSeco = Math.ceil(ItensSeco.value / ITotaSeco.value);
            SacolaItensMolhado = Math.ceil(ItensMolhado.value / ITotaMolhado.value);
            SacolaItensFragil = Math.ceil(ItensFragil.value / ITotaFragil.value);
            alert("Quandidade de sacolas que o cliente precisa é de: \n" +
                "Itens Seco: " + ItensSeco.value + " divididos em: " + SacolaItensSeco + " Sacolas.\n" +
                "Itens Molhados: " + ItensMolhado.value + " divididos em: " + SacolaItensMolhado + " Sacolas.\n" +
                "Itens frageis: " + ItensFragil.value + " divididos em: " + SacolaItensFragil + " Sacolas."
            );
        }
    });
});

function DestacarTexto(nOpc) {
    if (nOpc == 1) {
        var Texto = document.getElementById("UtilizeMenosSacolas1");
        Texto.style.background = "darkblue";
        Texto.style.color = "white";
    } else if (nOpc == 2) {
        var Texto = document.getElementById("UtilizeMenosSacolas2");
        Texto.style.background = "darkblue";
        Texto.style.color = "white";
    } else if (nOpc == 3) {
        var Texto = document.getElementById("UtilizeMenosSacolas3");
        Texto.style.background = "darkblue";
        Texto.style.color = "white";
    } else {
        alert("Opção inválida." + nOpc);
    }

}

function RemoverDestaque(nOpc) {
    if (nOpc == 1) {
        var Texto = document.getElementById("UtilizeMenosSacolas1");
        Texto.style.background = "";
        Texto.style.color = "black";
    } else if (nOpc == 2) {
        var Texto = document.getElementById("UtilizeMenosSacolas2");
        Texto.style.background = "";
        Texto.style.color = "black";
    } else if (nOpc == 3) {
        var Texto = document.getElementById("UtilizeMenosSacolas3");
        Texto.style.background = "";
        Texto.style.color = "black";
    } else {
        alert("Opção inválida." + nOpc);
    }

}